
<div id = "bottom-bar">
    <div id = "bottom-window">
    </div>
    <small>
        &copy;2018, All Rights Reserved, 
        <a href="http://validator.w3.org/check?uri=referer" 
            target="_blank">Valid HTML</a> ~ 
        <a href="http://jigsaw.w3.org/css-validator/check/referer" 
            target="_blank">Valid CSS</a>
    </small>
</div>