
<!-- Popup Windows -->
<div class = "modal">
    <?php include "resources/libraries/reCaptcha/includes/simple.php";?>
    <p class="clear-recaptcha"></p>
</div>