
<!-- PHP Config File -->
<?php include 'resources/portal-config.php' ?>

<!DOCTYPE html>
<html lang = "en">
    <?php include 'resources/templates/header.php' ?>
    <body>
        <!-- Popup Windows -->
        <?php include 'resources/templates/modal.php' ?>
        <?php include 'resources/templates/nav-bar.php' ?>
        <div id = "main">
            <div id="big-container">
                <div id="big-leftColumn">
                    <div class="big-textBox" id="topic-1">
                        <?php include 'public-html/documents/bigResearch-1.html' ?>
                    </div>
                    <div class="big-textBox" id="topic-3">
                        <?php include 'public-html/documents/bigResearch-3.html' ?>
                    </div>
                </div>
                <div id="big-rightColumn"></div>
            </div>
        </div>
        <?php include 'resources/templates/footer.php' ?>
    </body>
</html> 