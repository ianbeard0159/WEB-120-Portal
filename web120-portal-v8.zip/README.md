# WEB-120-Portal
Link to AWS application: http://ianbeard0959web120portal-env.g7gt7yzhze.us-east-1.elasticbeanstalk.com/
